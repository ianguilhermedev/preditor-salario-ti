; Programa demonstrativo do uso das novas funcoes
; de Rotinas, Shifts e Rotates para a CPU-8Ev2.2
;
	LOD	55h	; inicializa o ACC com 01010101 bin
	CAL	Shift
	ROR	3	; obtenho  A2 = 10100010
	SRA	2	; obtenho  D8 = 11101000
	ROL	2	; obtenho  A3 = 10100011
	HLT
Shift	SHL	2	; obtenho  54 = 01010100
	CAL	Rol
	RET
	NOP
Rol	ROR	2	; obtenho  15 = 00010101
	RET
	HLT		; FIM

