; Programa demonstrativo do uso das novas funcoes
; de Shifts e Rotates para a CPU-8Ev2.2
;
	LOD	55h	; inicializa o ACC com 01010101 bin
	ROL	1	; obtenho  AA = 10101010
	ROR	4	; continua AA = 10101010
	SHL	2	; obtenho  A8 = 10101000
	SRA	2	; obtenho  EA = 11101010
	SHR	5	; obtenho  07 = 00000111
	HLT		; FIM

